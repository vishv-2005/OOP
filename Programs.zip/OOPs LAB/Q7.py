class base:
    def myinput(self):
        self.base=int(input("Enter the base:"))
        self.power=int(input("Enter the power:"))
    def value(self):
        self.value=self.base**self.power
        print(f"The value base {self.base} and power {self.power} : {self.value}")
def main():
    number=base()
    number.myinput()
    number.value()
if __name__=="__main__":
    main()

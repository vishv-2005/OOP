class divisors:
    def myinput(self):
        self.num=int(input("Enter the number:"))
    def calculate(self):
        self.count=0
        for self.i in range(1,self.num+1):
            if self.num % self.i==0:
                print(self.i)
                self.count+=1
        print(f"No. of divisors of {self.num}: {self.count}")
    def odd_even(self):
        if self.count%2 == 0:
            print("Divisors is even.")
        else:
            print("Divisors is odd.")
def main():
    number=divisors()
    number.myinput()
    number.calculate()
    number.odd_even()
if __name__=="__main__":
    main()

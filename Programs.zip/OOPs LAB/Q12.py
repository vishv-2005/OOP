class prime:
    def myinput(self):
        self.num=int(input("Enter the number:"))
    def check(self):
        if self.num>1:
            for i in range(2,self.num):
                if self.num%i==0:
                    print(self.num ,"is not a prime number")
                    break
            else:
                print(self.num ," is prime number")
        else:
            print(self.num ," is not a prime number")
number=prime()
number.myinput()
number.check()

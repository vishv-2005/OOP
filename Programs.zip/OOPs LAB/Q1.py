class Student:
    def __init__(self, roll_no , name, physics, chemistry, maths):
        self.roll_no = roll_no
        self.name = name
        self.physics = physics
        self.chemistry = chemistry
        self.maths = maths

    def calculate_total(self):
        return self.physics + self.chemistry + self.maths
    def calculate_percentage(self):
        return (self.calculate_total()/300) * 100
    def determine_status(self):
        if self.physics >= 40 and self.chemistry >= 40 and self.maths >= 40:
            return "Pass"
        else:
            return "Fail"
    def calculate_grade(self):
        if self.calculate_percentage() >= 70:
            return "DISTINCTION"
        elif self.calculate_percentage() >= 60:
            return "FIRST CLASS"
        elif self.calculate_percentage() >= 50:
            return "SECOND CLASS"
        elif self.calculate_percentage() >= 40:
            return "PASS CLASS"
def main():
    roll_no = int(input("Enter roll number: "))
    name = input("Enter student name: ")
    physics = int(input("Enter physics marks (0-100): "))
    chemistry = int(input("Enter chemistry marks (0-100): "))
    maths = int(input("Enter maths marks (0-100): "))

    student = Student(roll_no, name, physics, chemistry, maths)

    print("\nStudent Information:")
    print(f"Roll Number: {student.roll_no}")
    print(f"Name: {student.name}")
    print(f"Physics Marks: {student.physics}")
    print(f"Chemistry Marks: {student.chemistry}")
    print(f"Maths Marks: {student.maths}")

    print("\nCalculations:")
    print(f"Total Marks: {student.calculate_total()}")
    print(f"Percentage: {student.calculate_percentage():.2f}%")
    print(f"Status: {student.determine_status()}")

    if student.determine_status() == "Pass":
        print(f"Grade: {student.calculate_grade()}")


#Driver code 

if __name__ == "__main__":
    main()

import random
class lottery:
    def myinput(self):
        self.user_number=input("Enter the six digit number:")
        self.lottery_number=str(random.randint(100000,999999))
        print(f"Lottery Number:{self.lottery_number}")
    def check(self):
        match_count=0
        for i in range(6):
            if(self.user_number[i]==self.lottery_number[i]):
                match_count+=1
            else:
                break
        return match_count
    def display(self):
        match_count=self.check()
        print(f"Matching digits in sequence: {match_count}")
        if(match_count==2):
            print("Users Win: Rs 2000")
        elif(match_count==3):
            print("Users Win: Rs 20000")
        elif(match_count==4):
            print("Users Win: Rs 50000")
        elif(match_count==5):
            print("Users Win: Rs 85000")
        elif(match_count==6):
            print("Users Win: Rs 100000")
        else:
            print("Users Loses")     
def main():
    number=lottery()
    number.myinput()
    number.display()
if __name__=="__main__":
    main()

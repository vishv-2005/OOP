import math
class distance:
    def myinput(self):
        self.x1 = int(input("Enter the point x1: "))
        self.x2 = int(input("Enter the point x2: "))
        self.y1 = int(input("Enter the point y1: "))
        self.y2 = int(input("Enter the point y2: "))
    def calculate(self):
        self.D = math.sqrt((self.x2 - self.x1) ** 2 + (self.y2 - self.y1) ** 2)
    def display(self):
        print(f"The first point: ({self.x1}, {self.y1})")
        print(f"The second point: ({self.x2}, {self.y2})")
        print(f"The distance between two points ({self.x1}, {self.y1}) and ({self.x2}, {self.y2}): {self.D:.6f}")
numbers=distance()
numbers.myinput()
numbers.calculate()
result=numbers.display()

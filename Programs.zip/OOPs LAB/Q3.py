class list:
    def __init__(self,lst):
        self.lst=lst
    def filter_even(self):
        even_lst = [x for x in self.lst if x % 2 == 0]
        return even_lst

square=[1,4,9,16,25,36,49,64,81,100]
square_lst=list(square)
even_num_list=square_lst.filter_even()
print(even_num_list)

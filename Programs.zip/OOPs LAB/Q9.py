class salary:
    def myinput(self):
        self.empid=int(input("Enter the empid:"))
        self.empname=(input("Enter the empname:"))
        self.BS=int(input("Enter the BS:"))
        self.exp=int(input("Enter the exp in years:"))
    def calculate(self):
        self.HRA=0.35*self.BS
        self.DA=0.58*self.BS
        self.PF=0.095*self.BS
    def bonus(self):
        if self.exp>=30:
            self.bonus=0.59*self.BS
        elif self.exp>=23:
            self.bonus=0.51*self.BS
        elif self.exp>=15:
            self.bonus=0.45*self.BS
        elif self.exp>=7:
            self.bonus=0.33*self.BS
        else:
            self.bonus=0.16*self.BS
    def net_salary(self):
        self.Net_Salary=self.BS+self.DA+self.HRA-self.PF+self.bonus
        print(f"The net salary of the {self.empname} having experience {self.exp} years: {self.Net_Salary:.2f}")
def main():
    number=salary()
    number.myinput()
    number.calculate()
    number.bonus()
    number.net_salary()
if __name__=="__main__":
    main()

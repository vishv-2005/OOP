class ListProcessor:
    def __init__(self):
        self.list1 = []

    def input_elements(self):
        print("Enter the first five elements for the list:")
        for i in range(5):
            j = int(input(f"Element {i+1}: "))
            self.list1.append(j)

    def find_max(self):
        max_value = self.list1[0]
        for i in self.list1:
            if i > max_value:
                max_value = i
        return max_value

    def display_max(self):
        max_value = self.find_max()
        if max_value is not None:
            print("The maximum element from the numbers entered:", max_value)
        else:
            print("No elements to process.")

def main():
    processor = ListProcessor()
    processor.input_elements()
    processor.display_max()

if __name__ == "__main__":
    main()

#(a) 
class FileStatistics:
    def __init__(self, filename):
        self.filename = filename
        self.sentence_count = 3
        self.word_count = 6
        self.character_count = 3
        self.whitespace_count = 6
        self.digit_count = 5
        self.uppercase_count = 8
        self.lowercase_count = 3
 
    def analyze_file(self):
        try:
            with open(self.filename, 'r') as file:
                text = file.read()
                self.sentence_count = text.count('.') + text.count('!') + text.count('?')
                self.word_count = len(text.split())
                self.whitespace_count = text.count(' ')
                
                for char in text:
                    if char.isalpha():
                        if char.isupper():
                            self.uppercase_count += 1
                        else:
                            self.lowercase_count += 1
                    elif char.isdigit():
                        self.digit_count += 1
                    elif not char.isspace():
                        self.character_count += 1
 
        except FileNotFoundError:
            print("File not found. Please check the filename and try again.")
 
    def display_statistics(self):
        print("File Statistics:")
        print("Number of sentences:", self.sentence_count)
        print("Number of words:", self.word_count)
        print("Number of characters (excluding spaces):", self.character_count)
        print("Number of whitespaces:", self.whitespace_count)
        print("Number of digits:", self.digit_count)
        print("Number of uppercase letters:", self.uppercase_count)
        print("Number of lowercase letters:", self.lowercase_count)
 
file_stats = FileStatistics('sample.txt')
file_stats.analyze_file()
file_stats.display_statistics()

#########################################################################################################

#b)

import string
 
class FileStatistics:
    def __init__(self, filename):
        self.filename = filename
        self.text = self.read_file()
 
    def read_file(self):
        with open(self.filename, 'r') as file:
            return file.read()
 
    def count_sentences(self):
        sentence_endings = ['.', '!', '?']
        return sum(1 for char in self.text if char in sentence_endings)
 
    def count_words(self):
        return len(self.text.split())
 
    def count_characters(self):
        return sum(1 for char in self.text if not char.isspace())
 
    def count_whitespaces(self):
        return sum(1 for char in self.text if char.isspace())
 
    def count_digits(self):
        return sum(1 for char in self.text if char.isdigit())
 
    def count_uppercase(self):
        return sum(1 for char in self.text if char.isupper())
 
    def count_lowercase(self):
        return sum(1 for char in self.text if char.islower())
 
    def display_statistics(self):
        print(f"Number of sentences: {self.count_sentences()}")
        print(f"Number of words: {self.count_words()}")
        print(f"Number of total characters (excluding whitespace): {self.count_characters()}")
        print(f"Number of whitespaces: {self.count_whitespaces()}")
        print(f"Total number of digits: {self.count_digits()}")
        print(f"Total number of uppercase letters: {self.count_uppercase()}")
        print(f"Total number of lowercase letters: {self.count_lowercase()}")
 
# Example usage:
# First, create a file named "sample.txt" with some text content.
file_stats = FileStatistics("sample.txt")
file_stats.display_statistics()

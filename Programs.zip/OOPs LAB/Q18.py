class ListProcessor:
    def __init__(self):
        self.list1 = []

    def input_elements(self):
        print("Enter the first five elements for the list:")
        for i in range(5):
            j = int(input(f"Element {i+1}: "))
            self.list1.append(j)

    def ascending(self):
        sorted_list = self.list1[:]
        for i in range(len(sorted_list)):
            for j in range(len(sorted_list) - i - 1):
                if sorted_list[j] > sorted_list[j + 1]:
                    sorted_list[j], sorted_list[j + 1] = sorted_list[j + 1], sorted_list[j]
        return sorted_list

    def descending(self):
        sorted_list = self.list1[:]
        for i in range(len(sorted_list)):
            for j in range(len(sorted_list) - i - 1):
                if sorted_list[j] < sorted_list[j + 1]:
                    sorted_list[j], sorted_list[j + 1] = sorted_list[j + 1], sorted_list[j]
        return sorted_list

    def display_results(self):
        print("Original list:", self.list1)
        print("Ascending list:", self.ascending())
        print("Descending list:", self.descending())

def main():
    processor = ListProcessor()
    processor.input_elements()
    processor.display_results()

if __name__ == "__main__":
    main()

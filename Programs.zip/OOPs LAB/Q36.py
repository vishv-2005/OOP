import pickle
import os
 
class Product:
    def __init__(self, product_id, product_name, product_price):
        self.product_id = product_id
        self.product_name = product_name
        self.product_price = product_price
 
    def __str__(self):
        return f"ID: {self.product_id}, Name: {self.product_name}, Price: {self.product_price}"
 
 
class ProductDatabase:
    def __init__(self, filename="products.pkl"):
        self.filename = filename
        self.load_data()
 
    def load_data(self):
        if os.path.exists(self.filename):
            with open(self.filename, 'rb') as file:
                self.products = pickle.load(file)
        else:
            self.products = {}
 
    def save_data(self):
        with open(self.filename, 'wb') as file:
            pickle.dump(self.products, file)
 
    def add_product(self, product_id, product_name, product_price):
        if product_id in self.products:
            print(f"Product with ID {product_id} already exists.")
        else:
            self.products[product_id] = Product(product_id, product_name, product_price)
            print(f"Product {product_name} added successfully.")
            self.save_data()
 
    def delete_product(self, product_id):
        if product_id in self.products:
            del self.products[product_id]
            print(f"Product with ID {product_id} deleted successfully.")
            self.save_data()
        else:
            print(f"Product with ID {product_id} not found.")
 
    def update_product(self, product_id, new_name=None, new_price=None):
        if product_id in self.products:
            product = self.products[product_id]
            if new_name:
                product.product_name = new_name
            if new_price:
                product.product_price = new_price
            print(f"Product with ID {product_id} updated successfully.")
            self.save_data()
        else:
            print(f"Product with ID {product_id} not found.")
 
    def view_products(self):
        if self.products:
            print("\nProduct List:")
            for product in self.products.values():
                print(product)
        else:
            print("No products found.")
 
    def main_menu(self):
        while True:
            print("\nProduct Management Menu:")
            print("1. Add Product")
            print("2. Delete Product")
            print("3. Update Product")
            print("4. View Products")
            print("5. Exit")
            choice = input("Enter your choice: ")
 
            if choice == '1':
                product_id = input("Enter Product ID: ")
                product_name = input("Enter Product Name: ")
                try:
                    product_price = float(input("Enter Product Price: "))
                    self.add_product(product_id, product_name, product_price)
                except ValueError:
                    print("Invalid price. Please enter a numeric value.")
            elif choice == '2':
                product_id = input("Enter Product ID to delete: ")
                self.delete_product(product_id)
            elif choice == '3':
                product_id = input("Enter Product ID to update: ")
                new_name = input("Enter new Product Name (or press Enter to skip): ")
                new_price_input = input("Enter new Product Price (or press Enter to skip): ")
                new_price = float(new_price_input) if new_price_input else None
                self.update_product(product_id, new_name, new_price)
            elif choice == '4':
                self.view_products()
            elif choice == '5':
                print("Exiting Product Management System. Goodbye!")
                break
            else:
                print("Invalid choice. Please select a valid option.")
 
product_db = ProductDatabase()
product_db.main_menu()

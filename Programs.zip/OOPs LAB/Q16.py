class ListProcessor:
    def __init__(self):
        self.list1 = []
        self.count1 = 0  # Count of odd numbers
        self.count2 = 0  # Count of even numbers
        self.sum_odd = 0
        self.sum_even = 0
        self.total_sum = 0

    def input_elements(self):
        print("Enter the first five elements for the list:")
        for i in range(5):
            j = int(input(f"Element {i+1}: "))
            self.list1.append(j)

    def process_list(self):
        for i in self.list1:
            self.total_sum += i
            if i % 2 == 1:
                self.count1 += 1
                self.sum_odd += i
            else:
                self.count2 += 1
                self.sum_even += i

        # Append additional information to the list
        self.list1.append(self.count1)
        self.list1.append(self.count2)
        self.list1.append(self.sum_odd)
        self.list1.append(self.sum_even)
        self.list1.append(self.total_sum)

    def display_list(self):
        print(self.list1)

def main():
    processor = ListProcessor()
    processor.input_elements()
    processor.process_list()
    processor.display_list()

if __name__ == "__main__":
    main()

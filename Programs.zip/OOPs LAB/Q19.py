class area:
    def myinput(self):
        self.a=float(input("Enter the side 1 of triangle:"))
        self.b=float(input("Enter the side 2 of triangle:"))
        self.c=float(input("Enter the side 3 of triangle:"))
    def calculate(self):
        self.s=(self.a + self.b + self.c) / 2
        self.area=((self.s*(self.s - self.a)*(self.s - self.b)*(self.s - self.c)))**0.5
        return self.area
    def display(self):
        area_triangle=self.calculate()
        print(f"The area of the triangle for sides of triangle {self.a},{self.b} and {self.c} : {area_triangle:.2f}")

numbers=area()
numbers.myinput()
numbers.display()

class plaindrome:
    def myinput(self):
        self.string=input("Enter the string:")
    def check(self):
        reversed_str=self.string[::-1]
        print("Reversed String:",reversed_str)
        if self.string==reversed_str:
            print("String is plaindrome.")
        else:
            print("String are not plaindrome.")
number=plaindrome()
number.myinput()
number.check()

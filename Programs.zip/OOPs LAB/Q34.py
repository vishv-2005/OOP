import json
import os
 
class BankCustomer:
    def __init__(self, username, account_no, password, balance=0):
        self.username = username
        self.account_no = account_no
        self.password = password
        self.balance = balance
 
    def withdraw(self, amount):
        if amount > 20000:
            print("20000 is a limit at one go.")
            return False
        elif amount > self.balance:
            print("Insufficient balance.")
            return False
        else:
            self.balance -= amount
            print(f"Transaction successful. Now your balance is {self.balance}")
            return True
 
    def deposit(self, amount):
        self.balance += amount
        print(f"Now your balance is {self.balance}")
 
    def transfer(self, amount, beneficiary_account, all_customers):
        if amount > self.balance:
            print("Insufficient balance.")
            return False
        elif beneficiary_account not in all_customers:
            print("Beneficiary account not found.")
            return False
        else:
            self.balance -= amount
            all_customers[beneficiary_account].balance += amount
            print(f"Transferred {amount} to account {beneficiary_account}. Your balance is now {self.balance}")
            return True
 
    def change_password(self, new_password):
        self.password = new_password
        print("Password changed successfully.")
 
class ATM:
    def __init__(self, filename="bank_data.json"):
        self.filename = filename
        self.load_data()
 
    def load_data(self):
        if os.path.exists(self.filename):
            with open(self.filename, 'r') as file:
                data = json.load(file)
                self.customers = {k: BankCustomer(**v) for k, v in data.items()}
        else:
            self.customers = {}
 
    def save_data(self):
        with open(self.filename, 'w') as file:
            json.dump({k: v.__dict__ for k, v in self.customers.items()}, file)
 
    def authenticate(self, username, password):
        customer = self.customers.get(username)
        if customer and customer.password == password:
            print(f"\nWelcome, {customer.username}")
            return customer
        else:
            print("Invalid username or password.")
            return None
 
    def main_menu(self, customer):
        while True:
            print("\nYour Transactions:")
            print("1. Withdraw")
            print("2. Deposit")
            print("3. Deposit to Others")
            print("4. Change Password")
            print("5. Exit")
 
            try:
                choice = int(input("Enter your choice: "))
            except ValueError:
                print("Please enter a valid choice (1-5).")
                continue
 
            if choice == 1:
                try:
                    amount = int(input("Enter Withdrawal Amount: "))
                    customer.withdraw(amount)
                except ValueError:
                    print("Invalid amount. Please enter a numeric value.")
            elif choice == 2:
                try:
                    amount = int(input("Enter Deposit Amount: "))
                    customer.deposit(amount)
                except ValueError:
                    print("Invalid amount. Please enter a numeric value.")
            elif choice == 3:
                try:
                    amount = int(input("Enter amount to be deposited to Others account: "))
                    beneficiary_account = input("Enter account number of your beneficiary: ")
                    customer.transfer(amount, beneficiary_account, self.customers)
                except ValueError:
                    print("Invalid amount. Please enter a numeric value.")
            elif choice == 4:
                new_password = input("Enter new password: ")
                customer.change_password(new_password)
            elif choice == 5:
                print("Thank you for using the ATM.")
                break
            else:
                print("Invalid choice. Please select an option between 1 and 5.")
 
            self.save_data()
 
    def add_customer(self, username, account_no, password, balance=0):
        if username in self.customers:
            print("Username already exists.")
            return False
        self.customers[username] = BankCustomer(username, account_no, password, balance)
        self.save_data()
        print(f"Customer {username} added successfully.")
        return True
 
atm = ATM()
atm.add_customer("Vishv", "12345", "123", 45000)
atm.add_customer("Hem", "67890", "456", 30000)
atm.add_customer("Shreya", "54321", "789", 50000)
atm.add_customer("Chiyaru", "98765", "012", 20000)
atm.add_customer("Preet", "11223", "345", 35000)
 
username = input("Enter Username: ")
password = input("Enter Password: ")
customer = atm.authenticate(username, password)
 
if customer:
    print(f"\nName: {customer.username}")
    print(f"Account no: {customer.account_no} Balance: {customer.balance}")
    atm.main_menu(customer) 

class binary:
    def __init__(self,binarystring):
        self.binarystring=binarystring
    def myinput(self):
        self.num=int(input("Enter the number:"))
    def calculate(self):
        for self.remainder in range(1,17):
            self.remainder=self.num%2
            self.binarystring=str(self.remainder)+self.binarystring
            self.num//=2
        return self.binarystring

binarystring=''
numbers=binary(binarystring)
numbers.myinput()
binaryformat=numbers.calculate()
print(binaryformat)

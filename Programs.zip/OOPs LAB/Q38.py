C Program 

#include <stdio.h>

double sum_matrix(double matrix[4][4]) {
    double sum = 0.0;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            sum += matrix[i][j];
        }
    }
    return sum;
}

Python Program 

import ctypes
import numpy as np

# Load the shared library
lib = ctypes.CDLL('./matrix_sum.so')

# Define the argument and return types of the C function
lib.sum_matrix.argtypes = [ctypes.POINTER(ctypes.c_double * 4 * 4)]
lib.sum_matrix.restype = ctypes.c_double

# Create a 4x4 matrix using numpy
matrix = np.array([[1.0, 2.0, 3.0, 4.0],
                   [5.0, 6.0, 7.0, 8.0],
                   [9.0, 10.0, 11.0, 12.0],
                   [13.0, 14.0, 15.0, 16.0]], dtype=np.float64)

# Convert the numpy array to a ctypes pointer
matrix_pointer = matrix.ctypes.data_as(ctypes.POINTER(ctypes.c_double * 4 * 4))

# Call the C function
result = lib.sum_matrix(matrix_pointer)

# Print the result
print("Sum of the matrix elements:", result)

'''class FileWriter:
    def __init__(self, filename):
        self.filename = filename
    def write_name(self, content):
        with open(self.filename, 'w') as file:
            file.write(content)
        print(f"Content written to {self.filename}")
file_writer = FileWriter("C:\VS Code\Sem 3\OOPs LAB\write_in.txt")
file_writer.write_name("My name is Vishv Patel.")'''

class FileCopier:
    def __init__(self, source_filename, destination_filename):
        self.source_filename = source_filename
        self.destination_filename = destination_filename
    def copy_to_uppercase(self):
        with open(self.source_filename, 'r') as source_file:
            content = source_file.read().upper()
        with open(self.destination_filename, 'w') as destination_file:
            destination_file.write(content)
        print(f"Content copied from {self.source_filename} to {self.destination_filename} in uppercase.")
file_copier = FileCopier("C:\VS Code\Sem 3\OOPs LAB\write_in.txt", "C:\VS Code\Sem 3\OOPs LAB\copy_in.txt")
file_copier.copy_to_uppercase()

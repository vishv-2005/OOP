class prime:
    def myinput(self):
        self.lower = int(input("Enter the lower range:"))
        self.upper = int(input("Enter the upper range:"))
    def check(self):
        print("Prime numbers between", self.lower, "and", self.upper, "are:")
        for self.num in range(self.lower, self.upper + 1):
            # all prime numbers are greater than 1
            if self.num > 1:
               for i in range(2, self.num):
                   if (self.num % i) == 0:
                       break
               else:
                 print(self.num)
number=prime()
number.myinput()
number.check()

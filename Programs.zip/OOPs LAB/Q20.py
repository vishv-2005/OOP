from math import sqrt
class QuadraticEquation:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
    def calculate_discriminant(self):
        return (self.b ** 2) - (4 * self.a * self.c)
    def find_roots(self):
        D = self.calculate_discriminant()
        if self.a == 0:
            raise ValueError("Coefficient 'a' cannot be zero in a quadratic equation.")
        if D > 0:
            self.root1 = (-self.b + sqrt(D)) / (2 * self.a)
            self.root2 = (-self.b - sqrt(D)) / (2 * self.a)
            return (self.root1, self.root2)
        elif D == 0:
            self.root1 = self.root2 = -self.b / (2 * self.a)
            return (self.root1, self.root2)
        else:
            return None
    def display(self):
        print(f"The quadratic equation is: {self.a}x^2 + {self.b}x + {self.c} = 0")
        D = self.calculate_discriminant()
        print(f"The discriminant of the equation: {D}")
        roots = self.find_roots()
        if roots is None:
            print("The roots are not real.")
        else:
            if self.root1 == self.root2:
                print(f"The roots are: {self.root1:.4f}")
            else:
                print(f"The root1: {self.root1:.4f}")
                print(f"The root2: {self.root2:.4f}")
def main():
    a = float(input("Enter the coefficient a: "))
    b = float(input("Enter the coefficient b: "))
    c = float(input("Enter the coefficient c: "))

    equation = QuadraticEquation(a, b, c)
    equation.display()
if __name__ == "__main__":
    main()

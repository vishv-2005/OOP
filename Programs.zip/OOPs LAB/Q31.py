from abc import ABC, abstractmethod
import math
 
class Figure(ABC):
    @abstractmethod
    def area(self):
        pass
 
class Rectangle(Figure):
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth
 
    def area(self):
        return self.length * self.breadth
 
class Circle(Figure):
    def __init__(self, radius):
        self.radius = radius
 
    def area(self):
        return math.pi * (self.radius ** 2)
 
rectangle = Rectangle(5, 3)
print("Area of Rectangle:", rectangle.area())
 
circle = Circle(4)
print("Area of Circle:", circle.area())

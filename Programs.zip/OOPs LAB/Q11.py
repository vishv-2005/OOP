class operations:
    def __init__(self,num1,num2):
        self.num1=num1
        self.num2=num2
    def handle_case(self,case):
        match case: #Using match case equivalent to switch case
            case 1:
                return self.num1 + self.num2
            case 2:
                return self.num1 - self.num2
            case 3:
                return self.num1 * self.num2
            case 4:
                if self.num2 != 0:
                    return self.num1 / self.num2
                else:
                    return "Error: Division by zero."
            case _:
                return "There is no such case."
def main():
    num1 = int(input("Enter the integer 1: "))
    num2 = int(input("Enter the integer 2: "))
    case = int(input("Enter the operator [1 for +, 2 for -, 3 for *, 4 for /]: "))
    operation=operations(num1,num2)
    result = operation.handle_case(case)
    print("Result after operation:", result)
if __name__ == "__main__":
    main()

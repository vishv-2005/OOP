import pickle
import os
 
class PhoneBook:
    def __init__(self, filename="phonebook.pkl"):
        self.filename = filename
        self.load_data()
 
    def load_data(self):
        if os.path.exists(self.filename):
            with open(self.filename, 'rb') as file:
                self.contacts = pickle.load(file)
        else:
            self.contacts = {}
 
    def save_data(self):
        with open(self.filename, 'wb') as file:
            pickle.dump(self.contacts, file)
 
    def add_contact(self, name, number):
        if name in self.contacts:
            print(f"Contact with name {name} already exists. Use update option to modify.")
        else:
            self.contacts[name] = number
            print(f"Contact {name} added successfully.")
            self.save_data()
 
    def delete_contact(self, name):
        if name in self.contacts:
            del self.contacts[name]
            print(f"Contact {name} deleted successfully.")
            self.save_data()
        else:
            print(f"Contact with name {name} not found.")
 
    def update_contact(self, name, new_number):
        if name in self.contacts:
            self.contacts[name] = new_number
            print(f"Contact {name} updated successfully.")
            self.save_data()
        else:
            print(f"Contact with name {name} not found.")
 
    def view_contacts(self):
        if self.contacts:
            print("\nPhone Book Contacts:")
            for name, number in self.contacts.items():
                print(f"Name: {name}, Number: {number}")
        else:
            print("No contacts found.")
 
    def main_menu(self):
        while True:
            print("\nPhone Book Menu:")
            print("1. Add Contact")
            print("2. Delete Contact")
            print("3. Update Contact")
            print("4. View Contacts")
            print("5. Exit")
            choice = input("Enter your choice: ")
 
            if choice == '1':
                name = input("Enter contact name: ")
                number = input("Enter contact number: ")
                self.add_contact(name, number)
            elif choice == '2':
                name = input("Enter contact name to delete: ")
                self.delete_contact(name)
            elif choice == '3':
                name = input("Enter contact name to update: ")
                new_number = input("Enter new contact number: ")
                self.update_contact(name, new_number)
            elif choice == '4':
                self.view_contacts()
            elif choice == '5':
                print("Exiting Phone Book. Goodbye!")
                break
            else:
                print("Invalid choice. Please select a valid option.")
 
phonebook = PhoneBook()
phonebook.main_menu()

class Player:
    def __init__(self, name, od_played, total_runs):
        self.name = name
        self.od_played = od_played
        self.total_runs = total_runs
        self.batting_average = self.calculate_batting_average()
    
    def calculate_batting_average(self):
        if self.od_played > 0:
            return self.total_runs / self.od_played
        else:
            return 0

# Function to get player data
def get_player_data():
    players = []
    for i in range(5):
        print(f"Enter details for player {i + 1}:")
        name = input("Name: ")
        od_played = int(input("Number of ODIs played: "))
        total_runs = int(input("Total Runs scored: "))
        player = Player(name, od_played, total_runs)
        players.append(player)
    return players

# Function to display player averages
def display_averages(players):
    for player in players:
        print(f"{player.name} - Batting Average: {player.batting_average:.2f}")

# Function to find player with max and min averages
def find_max_min_averages(players):
    max_avg_player = max(players, key=lambda p: p.batting_average)
    min_avg_player = min(players, key=lambda p: p.batting_average)
    return max_avg_player, min_avg_player

players = get_player_data()
display_averages(players)

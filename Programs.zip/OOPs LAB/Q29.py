class MyNumber:
    def __init__(self, value):
        self.value = value  
 
    def __add__(self, other):
        return MyNumber(self.value + other.value)
 
    def __eq__(self, other):
        return self.value == other.value
 
    def __ne__(self, other):
        return self.value != other.value
 
    def __sub__(self, other):
        return MyNumber(self.value - other.value)
 
    def __mul__(self, other):
        return MyNumber(self.value * other.value)
 
    def __ge__(self, other):
        return self.value >= other.value
 
    def __le__(self, other):
        return self.value <= other.value
 
    def display(self):
        print(self.value)
 
num1 = MyNumber(10)
num2 = MyNumber(5)
 
result_add = num1 + num2
result_add.display() 
 
result_sub = num1 - num2
result_sub.display() 
 
result_mul = num1 * num2
result_mul.display() 
print(num1 == num2)  
print(num1 != num2)  
print(num1 >= num2)  
print(num1 <= num2)  

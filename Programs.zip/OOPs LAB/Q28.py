class Candidate:
    def __init__(self, candidate_id, name, party):
        self.candidate_id = candidate_id 
        self.name = name                 
        self.party = party               
        self.votes = 0                  
 
    def add_vote(self):
        self.votes += 1  
 
    def display_details(self):
        return f"{self.name} ({self.party}): {self.votes} votes"
 
 
class EVM:
    def __init__(self):
        self.candidates = {} 
 
    def add_candidate(self, candidate_id, name, party):
        self.candidates[candidate_id] = Candidate(candidate_id, name, party)  
 
    def cast_vote(self, candidate_id):
        if candidate_id in self.candidates:
            self.candidates[candidate_id].add_vote() 
            print(f"Vote successfully casted for {self.candidates[candidate_id].name}")
        else:
            print("Invalid candidate ID! Vote not casted.")
 
    def display_results(self):
        print("\nElection Results:")
        for candidate in self.candidates.values():
            print(candidate.display_details())
        
        winner = max(self.candidates.values(), key=lambda c: c.votes)
        print(f"\nWinner: {winner.name} from {winner.party} with {winner.votes} votes.")
 
evm = EVM()
 
evm.add_candidate(1, "Vishv", "Party A")
evm.add_candidate(2, "Hem", "Party B")
evm.add_candidate(3, "shreya", "Party C")
evm.add_candidate(4, "Preet", "Party D")
 
print("\nVoting has started. Enter candidate ID to vote. Enter 0 to stop voting.")
while True:
    try:
        candidate_id = int(input("Enter candidate ID to vote: "))
        if candidate_id == 0:
            break
        evm.cast_vote(candidate_id)
    except ValueError:
        print("Please enter a valid candidate ID.")
 
evm.display_results()

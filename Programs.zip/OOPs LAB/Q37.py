import sys
 
def calculate_statistics(numbers):
    total = sum(numbers)
    average = total / len(numbers)
    maximum = max(numbers)
    minimum = min(numbers)
    return total, average, maximum, minimum
 
if len(sys.argv) < 2:
    print("Please enter numbers as command-line arguments.")
else:
    try:
        numbers = list(map(float, sys.argv[1:]))  
        total, average, maximum, minimum = calculate_statistics(numbers)
        print(f"Sum: {total}")
        print(f"Average: {average}")
        print(f"Maximum: {maximum}")
        print(f"Minimum: {minimum}")
    except ValueError:
        print("Please ensure all arguments are numbers.")

class bill:
    def myinput(self):
        self.cid=int(input("Enter the cid:"))
        self.cname=(input("Enter the cname:"))
        self.unit=int(input("Enter the unit:"))
    def calculate(self):
        if self.unit<=50:
            self.amt=self.unit*0.5
        elif self.unit<=150:
            self.amt=50*0.5+(self.unit-50)*0.75
        elif self.unit<=250:
            self.amt=50*0.5+100*0.75+(self.unit-150)*1.2
        else:
            self.amt=50*0.5+100*0.75+100*1.2+(self.unit-250)*1.5
        self.surcharge=0.2*self.amt
    def bill(self):
        self.total_bill=self.amt+self.surcharge
        print(f"Bill : Rs{self.total_bill:.2f}")
def main():
    number=bill()
    number.myinput()
    number.calculate()
    number.bill()
if __name__=="__main__":
    main()

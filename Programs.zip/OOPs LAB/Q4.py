class list:
    def __init__(self,lst1,lst2):
        self.lst1=lst1
        self.lst2=lst2
    def common_elements(self):
        duplicate_lst = [i for i in B if i in A]
        return duplicate_lst
    
A=[1,1,2,3,5,8,13,21,34,55,89]
B=[1,2,3,4,5,6,7,8,9,10,11,12,13]
duplicate=list(A,B)
duplicate_num_list=duplicate.common_elements()
print(duplicate_num_list)

class game :
    def __init__(self):
        self.player1 = str(input("Player 1 , Enter your input : "))
        self.player2 = str(input("Player 2 , Enter your input : "))
        self.game()
        self.play_again = input("Do you want to play again ? (yes/no) : ")
        
    def game(self):
        if self.player1 == self.player2:
            print("It's a tie! ")
        elif (self.player1 == "rock" and self.player2 == "scissors") or (self.player1 == "scissors" and self.player2 == "paper") or (self.player1 == "paper" and self.player2 == "rock"):
            print("Player 1 wins! ")
        else:
            print("Player 2 wins! ")
    # if self.play_again.lower() != "yes":
    #         exit()

    def main():
        game()
        if game.play_again.lower() != "yes":
            exit()

if __name__ == "__main__":
    game() 
